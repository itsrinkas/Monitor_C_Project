var files_dup =
[
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "MenuFunctions.c", "_menu_functions_8c.html", "_menu_functions_8c" ],
    [ "WorkingFunctions.c", "_working_functions_8c.html", "_working_functions_8c" ],
    [ "WorkingFunctions.h", "_working_functions_8h.html", "_working_functions_8h" ]
];