var _menu_functions_8c =
[
    [ "UNUSED", "_menu_functions_8c.html#addf5ec070e9499d36b7f2009ce736076", null ],
    [ "MF1", "_menu_functions_8c.html#ac364321ed7523926efdf143601d90343", null ],
    [ "MF2", "_menu_functions_8c.html#aee2adfca4f481e55a148e5bcfc4f4bd3", null ],
    [ "MF3", "_menu_functions_8c.html#a3076918b405f777abd765c296b050d67", null ],
    [ "MF4", "_menu_functions_8c.html#a72571c7072ae0c67833db57358114fa5", null ]
];