var searchData=
[
  ['unused_0',['UNUSED',['../_menu_functions_8c.html#addf5ec070e9499d36b7f2009ce736076',1,'UNUSED:&#160;MenuFunctions.c'],['../_working_functions_8c.html#addf5ec070e9499d36b7f2009ce736076',1,'UNUSED:&#160;WorkingFunctions.c'],['../_working_functions_8h.html#addf5ec070e9499d36b7f2009ce736076',1,'UNUSED:&#160;WorkingFunctions.h']]]
];
