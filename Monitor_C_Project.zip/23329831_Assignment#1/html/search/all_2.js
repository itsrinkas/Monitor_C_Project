var searchData=
[
  ['printallelements_0',['PrintAllElements',['../_working_functions_8c.html#a2199b93e43f304d1dcd2528c43a8aa5b',1,'PrintAllElements(const double *array, int capacity):&#160;WorkingFunctions.c'],['../_working_functions_8h.html#a2199b93e43f304d1dcd2528c43a8aa5b',1,'PrintAllElements(const double *array, int capacity):&#160;WorkingFunctions.c']]],
  ['printusedelements_1',['PrintUsedElements',['../_working_functions_8c.html#ae718e50acff477a2cf16f66a6e1b5714',1,'PrintUsedElements(const double *array, int capacity):&#160;WorkingFunctions.c'],['../_working_functions_8h.html#ae718e50acff477a2cf16f66a6e1b5714',1,'PrintUsedElements(const double *array, int capacity):&#160;WorkingFunctions.c']]]
];
